const calculateTemp=()=>{
    const numberTemp=document.getElementById('temp').value;
    const tempSelected=document.getElementById('temp_diff');
    const valueTemp=temp_diff.options[tempSelected.selectedIndex].value;
    const celToFah=(cel)=>{
        let fahrenheit=((cel*9/5)+32);
        return fahrenheit;
    }
    const fahToCel=(fah)=>{
        let celsius=((fah-32)*5/9);
        return celsius;
    }
    const fahToKel=(fah)=>{
        let kelvin=(((fah-32)*5/9)+273.15);
        return kelvin;
    }
    const kelToFah=(kel)=>{
        let fahrenheit=(((kel-273.15)*9/5)+32);
        return fahrenheit;
    }
    const kelToCel=(kel)=>{
        let celsius=(kel-273.15);
        return celsius;
    }
    const celToKel=(cel)=>{
        let kelvin = ((cel-273.15)+546.3);
        return kelvin;
    }

    let result;
    let result2;
    
    if(valueTemp=='cel')
    {
        result= celToFah(numberTemp);
        document.getElementById('result').innerHTML=`= ${result} Fahrenheit`;
        result2= celToKel(numberTemp);
        document.getElementById('result2').innerHTML=`= ${result2} kelvin`;
        
    }
    else if(valueTemp=='kel'){
        result= kelToFah(numberTemp);
        document.getElementById('result').innerHTML=`= ${result} Fahrenheit`;
        result2= kelToCel(numberTemp);
        document.getElementById('result2').innerHTML=`= ${result2} Celsius`;

    }
    else 
    {
        result= fahToCel(numberTemp);
        document.getElementById('result').innerHTML=`= ${result} Celsius`;
        result2= fahToKel(numberTemp);
        document.getElementById('result2').innerHTML=`= ${result2} Kelvin`;
    }
}